public abstract class ABS {
    int a = 10;
    ABS()
    {
        System.out.println("Abstract class Constructor");
    }
    abstract void display();
}

class hell extends ABS
{
    hell()
    {
        System.out.println("Hell constructor");
    }
    void display()
    {
        System.out.println("Display method of hell class");
    }

    public static void main(String[] args)
    {
        ABS a = new hell();
        a.display();
    }
}
