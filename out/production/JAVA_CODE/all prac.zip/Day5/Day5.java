

import java.util.Scanner;

public class Day5 {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a character : ");
        char c = (char)sc.nextLine().charAt(0);
                System.out.println("ASCII : "+(int)c);

    }
}
