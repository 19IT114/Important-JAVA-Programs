package pkgUnitTest1.pkgStringOccurrence;

public interface StringOccurrence {
    void removeOccurrence(String input,char c);
}
