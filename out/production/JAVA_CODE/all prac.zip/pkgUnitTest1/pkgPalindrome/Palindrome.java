package pkgUnitTest1.pkgPalindrome;

public interface Palindrome {
    void CheckPalindrome(String input);
}
