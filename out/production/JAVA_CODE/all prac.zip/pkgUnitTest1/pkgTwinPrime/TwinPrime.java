package pkgUnitTest1.pkgTwinPrime;

public interface TwinPrime {
    void generateSeries(int Number);
}
