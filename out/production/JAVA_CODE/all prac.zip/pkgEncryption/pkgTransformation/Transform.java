package pkgEncryption.pkgTransformation;

public interface Transform {
    public void encrypt(String input);
}
