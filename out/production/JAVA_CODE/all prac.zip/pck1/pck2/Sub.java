package pck1.pck2;

public interface Sub {
    public double Sub(double a, double b);

}
