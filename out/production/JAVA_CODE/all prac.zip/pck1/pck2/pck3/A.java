package pck1.pck2.pck3;

public class A {
    public static void main(String[] args) {
        Calculator c = new Calculator();
        c.Calc();
    }
}
