package pck1;

public interface Add {
    public double Add(double a, double b);
}
