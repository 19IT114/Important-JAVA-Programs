package week_10;

public class UserDefinedException extends Exception{
    UserDefinedException(String a)
    {
        super(a);
    }
//    public String toString()
//    {
//        return "Inside User Defined Exception Class";
//
//    }
}
