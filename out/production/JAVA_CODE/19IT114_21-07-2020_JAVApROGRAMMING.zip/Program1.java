public class Program1 {
    void display()
    {
        System.out.println("Hello, How are You!");
        System.out.println("What are you doing..?");
    }
    public static void main(String args[])
    {
        Program1 a = new  Program1();
        a.display();
    }
}
