public class Program5 {
    public static void main(String ar[])
    {
        Program5 p = new Program5();
        System.out.println("Second element is "+ar[1]);
    }
}
