public class Program2 {
    void display()
    {
        System.out.println("Shastri said:\"Sachin has played a game of his Life.\"");

    }
    public static void main(String args[])
    {
        Program2 a2 = new  Program2();
        a2.display();
    }
}
