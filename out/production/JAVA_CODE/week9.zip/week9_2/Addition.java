package week9_2;

public class Addition {
     public double getSum(double a,double b)
    {
        return a+b;
    }
}
